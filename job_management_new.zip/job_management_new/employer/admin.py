from django.contrib import admin
from .models import hrreg,PostJob

admin.site.register(hrreg)
admin.site.register(PostJob)
