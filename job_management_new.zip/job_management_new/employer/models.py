from django.db import models

class hrreg(models.Model):
	Full_Name = models.CharField(max_length=30)
	Company_Name = models.CharField(max_length=30)
	Email = models.CharField(max_length=30)
	Password = models.CharField(max_length=30,default='')
	Mobile = models.CharField(max_length=12)
	Status = models.CharField(max_length=1)

	def __str__(self):
		return self.Full_Name+" "+self.Company_Name


class PostJob(models.Model):
	Technology = models.CharField(max_length=50)
	Job_Description = models.CharField(max_length=50)
	Experience = models.CharField(max_length=30)
	Company_Name = models.CharField(max_length=50)
	Company_Email = models.CharField(max_length=30)
	Company_Contact = models.CharField(max_length=12)
	Post_Date = models.DateField()
	Expiry_Date = models.DateField()
	Status = models.CharField(max_length=1)

	def __str__(self):
		return self.Company_Name+" "+self.Technology

class AppliedStudent(models.Model):
	job_applied_id = models.CharField(max_length=1000)
	student_name = models.CharField(max_length=50)
	student_number = models.CharField(max_length = 12)
	technology = models.CharField(max_length=100,default='')
	email = models.CharField(max_length=100,default='')
	resume = models.CharField(max_length=100)

	def __str__(self):
		return self.student_name
	