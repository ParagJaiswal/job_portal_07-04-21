from django.contrib import admin
from . models import AdminLogin,CourseData,StudentRecord
from employer.models import AppliedStudent


admin.site.register(AdminLogin)
admin.site.register(CourseData)
admin.site.register(StudentRecord)
admin.site.register(AppliedStudent)


